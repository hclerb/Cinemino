<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_4ca5045dffd7343b51fe692c3812a8a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("TwigBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "exception"), "message"), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, $this->getContext($context, "status_code"), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getContext($context, "status_text"), "html", null, true);
        echo ")
";
    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $this->env->loadTemplate("TwigBundle:Exception:exception.html.twig")->display($context);
    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  29 => 3,  198 => 80,  193 => 76,  187 => 5,  177 => 115,  173 => 114,  169 => 113,  126 => 76,  106 => 59,  102 => 58,  97 => 56,  82 => 44,  75 => 40,  48 => 16,  40 => 14,  22 => 1,  133 => 80,  128 => 77,  120 => 33,  115 => 53,  113 => 51,  104 => 48,  99 => 47,  94 => 46,  88 => 41,  81 => 36,  79 => 33,  63 => 23,  59 => 22,  44 => 15,  41 => 8,  35 => 3,  32 => 4,  54 => 11,  52 => 10,  49 => 9,  30 => 2,  72 => 20,  67 => 24,  60 => 14,  55 => 12,  51 => 11,  46 => 8,  42 => 8,  39 => 6,  33 => 3,  31 => 4,  28 => 5,);
    }
}
