<?php

/* CineminotestBundle:Cinema:show.html.twig */
class __TwigTemplate_4b47cf8de29e45d2720be4d336d1e66c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("CineminotestBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'alert' => array($this, 'block_alert'),
            'titre' => array($this, 'block_titre'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "CineminotestBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        $this->displayParentBlock("title", $context, $blocks);
        echo " -  Accueil
";
    }

    // line 7
    public function block_alert($context, array $blocks = array())
    {
        echo "Ici vous pouvez gérer l'ensemble des cinémas dont vous avez la charge ( modification / visualisation ) ";
    }

    // line 9
    public function block_titre($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "nomCinema"), "html", null, true);
    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        // line 13
        echo "
  <td> <img class=\"img-polaroid\" width=\"450\" src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "photo"), "html", null, true);
        echo "\" alt=\"\"/></td>
  <td> <img class=\"img-polaroid\" width=\"250px\" src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "logo"), "html", null, true);
        echo "\" alt=\"\"/></td>
<br><br>
<table class=\"record_properties\">
    <tbody>
    
        <tr>
            <th>Adresse :</th>
            <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "adresse"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Adresse mail :</th>
            <td>";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "adresseMail"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Coordonnees tel :</th>
            <td>";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "coordonneesTel"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Site web :</th>
            <td>";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "siteWeb"), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <th>Couleur de fond :</th>
            <td style=\"background-color:";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "couleurFondCinema"), "html", null, true);
        echo "\"></td>
        </tr>
        <tr>
            <th>Type :</th>
            <td>";
        // line 42
        if (($this->getAttribute($this->getContext($context, "entity"), "type") == "i")) {
            echo "Itinérant ";
        } else {
            echo "Normal";
        }
        echo "</td>
        </tr>
    </tbody>
</table>

<br><br>


   
        <a class=\"btn\" href=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("cinema"), "html", null, true);
        echo "\"><i class=\"icon-arrow-left\"></i> Revenir a la liste</a>
   

        
        <a class=\"btn\" href=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("cinema_edit", array("id" => $this->getAttribute($this->getContext($context, "entity"), "id"))), "html", null, true);
        echo "\"><i class=\"icon-pencil\"></i> Editer</a>
            
<br><br>
    
        <form action=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("cinema_delete", array("id" => $this->getAttribute($this->getContext($context, "entity"), "id"))), "html", null, true);
        echo "\" method=\"post\">
            ";
        // line 60
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getContext($context, "delete_form"), 'widget');
        echo "
            <button class=\"btn btn-danger\" type=\"submit\"><i class=\"icon-remove icon-white\"></i> Supprimer ";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "entity"), "nomCinema"), "html", null, true);
        echo "</button>
        </form>
   


";
    }

    public function getTemplateName()
    {
        return "CineminotestBundle:Cinema:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 59,  86 => 30,  62 => 15,  193 => 76,  187 => 5,  177 => 115,  173 => 114,  169 => 113,  82 => 44,  113 => 51,  99 => 47,  112 => 37,  97 => 56,  87 => 30,  77 => 28,  40 => 7,  23 => 3,  479 => 162,  473 => 161,  468 => 158,  460 => 155,  456 => 153,  452 => 151,  443 => 149,  439 => 148,  436 => 147,  434 => 146,  429 => 144,  426 => 143,  422 => 142,  412 => 134,  408 => 132,  406 => 131,  401 => 130,  397 => 129,  392 => 126,  386 => 122,  383 => 121,  380 => 120,  378 => 119,  373 => 116,  367 => 112,  364 => 111,  361 => 110,  359 => 109,  354 => 106,  340 => 105,  336 => 103,  321 => 101,  313 => 99,  311 => 98,  308 => 97,  304 => 95,  297 => 91,  293 => 90,  284 => 89,  282 => 88,  277 => 86,  267 => 85,  263 => 84,  257 => 81,  251 => 80,  246 => 78,  240 => 77,  234 => 74,  228 => 73,  223 => 71,  219 => 70,  213 => 69,  207 => 68,  198 => 80,  181 => 66,  176 => 65,  170 => 61,  168 => 60,  146 => 58,  142 => 56,  128 => 77,  125 => 44,  107 => 42,  38 => 6,  144 => 53,  141 => 60,  135 => 47,  126 => 76,  109 => 41,  103 => 37,  67 => 24,  61 => 13,  47 => 9,  105 => 24,  93 => 34,  76 => 16,  72 => 22,  68 => 12,  27 => 4,  91 => 31,  84 => 28,  94 => 46,  88 => 41,  79 => 26,  59 => 22,  21 => 2,  44 => 15,  31 => 3,  28 => 5,  225 => 96,  216 => 90,  212 => 88,  205 => 84,  201 => 83,  196 => 80,  194 => 79,  191 => 78,  189 => 77,  186 => 76,  180 => 72,  172 => 67,  159 => 61,  154 => 59,  147 => 55,  132 => 48,  127 => 44,  121 => 45,  118 => 44,  114 => 42,  104 => 48,  100 => 38,  78 => 21,  75 => 40,  71 => 19,  58 => 14,  34 => 4,  26 => 6,  24 => 3,  25 => 3,  19 => 1,  70 => 26,  63 => 23,  46 => 9,  22 => 1,  163 => 59,  155 => 58,  152 => 49,  149 => 48,  145 => 61,  139 => 55,  131 => 51,  123 => 51,  120 => 33,  115 => 53,  106 => 59,  101 => 32,  96 => 21,  83 => 29,  80 => 24,  74 => 27,  66 => 15,  55 => 13,  52 => 12,  50 => 10,  43 => 7,  41 => 8,  37 => 8,  35 => 3,  32 => 2,  29 => 4,  184 => 70,  178 => 71,  171 => 62,  165 => 58,  162 => 57,  157 => 60,  153 => 54,  151 => 53,  143 => 54,  138 => 51,  136 => 50,  133 => 80,  130 => 55,  122 => 41,  119 => 42,  116 => 35,  111 => 37,  108 => 36,  102 => 58,  98 => 31,  95 => 34,  92 => 33,  89 => 19,  85 => 25,  81 => 36,  73 => 19,  64 => 17,  60 => 23,  57 => 11,  54 => 10,  51 => 14,  48 => 16,  45 => 8,  42 => 7,  39 => 9,  36 => 5,  33 => 4,  30 => 7,);
    }
}
