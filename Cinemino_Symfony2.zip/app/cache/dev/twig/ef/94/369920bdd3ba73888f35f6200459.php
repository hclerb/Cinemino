<?php

/* ::layout.html.twig */
class __TwigTemplate_ef94369920bdd3ba73888f35f6200459 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'info' => array($this, 'block_info'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"Shades of gunmetal gray.\">
    <meta name=\"author\" content=\"Thomas Park\">

    <!--[if lt IE 9]>
      <script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script>
    <![endif]-->

    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/css/bootstrap-responsive.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/css/bootswatch.css\" rel=\"stylesheet"), "html", null, true);
        echo "\">

  </head>

  <body class=\"preview\" data-spy=\"scroll\" data-target=\".subnav\" data-offset=\"80\">


<!-- Navbar
================================================== -->
<section id=\"navbar\">
  <div class=\"page-header\">
    <h1>Cinémino</h1>
  </div>
  <div class=\"navbar navbar-inverse\">
    <div class=\"navbar-inner\">
      <div class=\"container\" style=\"width: auto;\">
        <a class=\"btn btn-navbar\" data-toggle=\"collapse\" data-target=\".nav-collapse\">
          <span class=\"icon-bar\"></span>
          <span class=\"icon-bar\"></span>
          <span class=\"icon-bar\"></span>
        </a>
        <a class=\"brand\" href=\"#\">Panel Admin</a>
        <div class=\"nav-collapse\">
          <ul class=\"nav\">
            <li class=\"active\"><a href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("cineminotest_accueil"), "html", null, true);
        echo "\">Accueil</a></li>
            <li><a href=\"#\">Ajouter / Modifier une séance</a></li>
             <li><a href=\"#\">Evènements</a></li>
             <li><a href=\"#\">Gérer les intervenants</a></li>
            <li><a href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("cinema"), "html", null, true);
        echo "\">Gérer les cinémas</a></li>
            <li><a href=\"#\">Administration des utilisateurs</a></li>>
          </ul>
          <form class=\"navbar-search pull-left\" action=\"\">
            <input type=\"text\" class=\"search-query span2\" placeholder=\"Search\">
          </form>
          <ul class=\"nav pull-right\">
            <li><a href=\"#\">Accéder au site</a></li>
            <li class=\"divider-vertical\"></li>
            <li class=\"dropdown\">
              <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"> Admin <b class=\"caret\"></b></a>
              <ul class=\"dropdown-menu\">
                <li><a href=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("fos_user_profile_edit"), "html", null, true);
        echo "\">Modifier Profil</a></li>
                <li class=\"divider\"></li>
                <li>   <a href=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("fos_user_security_logout"), "html", null, true);
        echo "\">
                    ";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Déconnexion", array(), "FOSUserBundle"), "html", null, true);
        echo "
                </a>
                </li>
              </ul>
            </li>
          </ul>
        </div><!-- /.nav-collapse -->
      </div>
    </div><!-- /navbar-inner -->
  </div><!-- /navbar -->

</section>

    <div class=\"container\">

<section id =\"information\">
    
   ";
        // line 76
        $this->displayBlock('info', $context, $blocks);
        // line 77
        echo "    

   
";
        // line 80
        $this->displayBlock('javascripts', $context, $blocks);
        echo "    
    
</section>
   
     <!-- Footer
      ================================================== -->
      <hr>

      <footer id=\"footer\">
        <p class=\"pull-right\"><a href=\"#\">Revenir en haut</a></p>
        <div class=\"links\">
          <a href=\"http://news.bootswatch.com\" onclick=\"pageTracker._link(this.href); return false;\">Blog</a>
          <a href=\"http://feeds.feedburner.com/bootswatch\">RSS</a>
          <a href=\"https://twitter.com/thomashpark\">Twitter</a>
          <a href=\"https://github.com/thomaspark/bootswatch/\">GitHub</a>
          <a rel=\"tooltip\" href=\"javascript:(function(e,a,g,h,f,c,b,d)%7Bif(!(f%3De.jQuery)%7C%7Cg%3Ef.fn.jquery%7C%7Ch(f))%7Bc%3Da.createElement(%22script%22)%3Bc.type%3D%22text/javascript%22%3Bc.src%3D%22http://ajax.googleapis.com/ajax/libs/jquery/%22%2Bg%2B%22/jquery.min.js%22%3Bc.onload%3Dc.onreadystatechange%3Dfunction()%7Bif(!b%26%26(!(d%3Dthis.readyState)%7C%7Cd%3D%3D%22loaded%22%7C%7Cd%3D%3D%22complete%22))%7Bh((f%3De.jQuery).noConflict(1),b%3D1)%3Bf(c).remove()%7D%7D%3Ba.documentElement.childNodes%5B0%5D.appendChild(c)%7D%7D)(window,document,%221.3.2%22,function(%24,L)%7Bif(%24(%22.bootswatcher%22)%5B0%5D)%7B%24(%22.bootswatcher%22).remove()%7Delse%7Bvar%20%24e%3D%24(%27%3Cselect%20class%3D%22bootswatcher%22%3E%3Coption%3EAmelia%3C/option%3E%3Coption%3ECerulean%3C/option%3E%3Coption%3ECosmo%3C/option%3E%3Coption%3ECyborg%3C/option%3E%3Coption%3EJournal%3C/option%3E%3Coption%3EReadable%3C/option%3E%3Coption%3ESimplex%3C/option%3E%3Coption%3ESlate%3C/option%3E%3Coption%3ESpacelab%3C/option%3E%3Coption%3ESpruce%3C/option%3E%3Coption%3ESuperhero%3C/option%3E%3Coption%3EUnited%3C/option%3E%3C/select%3E%27)%3Bvar%20l%3D1%2BMath.floor(Math.random()*%24e.children().length)%3B%24e.css(%7B%22z-index%22:%2299999%22,position:%22fixed%22,top:%225px%22,right:%225px%22,opacity:%220.5%22%7D).hover(function()%7B%24(this).css(%22opacity%22,%221%22)%7D,function()%7B%24(this).css(%22opacity%22,%220.5%22)%7D).change(function()%7Bif(!%24(%22link.bootswatcher%22)%5B0%5D)%7B%24(%22head%22).append(%27%3Clink%20rel%3D%22stylesheet%22%20class%3D%22bootswatcher%22%3E%27)%7D%24(%22link.bootswatcher%22).attr(%22href%22,%22http://bootswatch.com/%22%2B%24(this).find(%22:selected%22).text().toLowerCase()%2B%22/bootstrap.min.css%22)%7D).find(%22option:nth-child(%22%2Bl%2B%22)%22).attr(%22selected%22,%22selected%22).end().trigger(%22change%22)%3B%24(%22body%22).append(%24e)%7D%3B%7D)%3B\" title=\"Drag to your bookmarks bar\">Bookmarklet</a>
          <a href=\"https://github.com/thomaspark/bootswatch/tree/gh-pages/swatchmaker\">Swatchmaker</a>
          <a href=\"http://news.bootswatch.com/post/22193315172/bootswatch-api\">API</a>
          <a href=\"https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=F22JEM3Q78JC2\">Donate</a>
        </div>
        Made by <a target=\"_blank\" href=\"http://thomaspark.me\" onclick=\"pageTracker._link(this.href); return false;\">Thomas Park</a>. Contact him <a href=\"mailto:hello@thomaspark.me\">hello@thomaspark.me</a>.<br/>
        Code licensed under the <a target=\"_blank\" href=\"http://www.apache.org/licenses/LICENSE-2.0\">Apache License v2.0</a>.<br/>
        Based on <a target=\"_blank\" href=\"http://twitter.github.com/bootstrap/\">Bootstrap</a>. Hosted on <a target=\"_blank\" href=\"http://pages.github.com/\">GitHub</a>. Icons from <a target=\"_blank\" href=\"http://glyphicons.com/\">Glyphicons</a>. Web fonts from <a target=\"_blank\" href=\"http://www.google.com/webfonts\">Google</a>.</p>
      </footer>

    </div><!-- /container -->



    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js\"></script>
    <script src=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 114
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/js/application.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 115
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("css/js/bootswatch.js"), "html", null, true);
        echo "\"></script>


  </body>
</html>
";
    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        echo "Cinémino: Panel Admin ";
    }

    // line 76
    public function block_info($context, array $blocks = array())
    {
    }

    // line 80
    public function block_javascripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  198 => 80,  193 => 76,  187 => 5,  177 => 115,  173 => 114,  169 => 113,  126 => 76,  106 => 59,  102 => 58,  97 => 56,  82 => 44,  75 => 40,  48 => 16,  40 => 14,  22 => 1,  133 => 80,  128 => 77,  120 => 33,  115 => 53,  113 => 51,  104 => 48,  99 => 47,  94 => 46,  88 => 41,  81 => 36,  79 => 33,  63 => 23,  59 => 22,  44 => 15,  41 => 8,  35 => 3,  32 => 2,  54 => 11,  52 => 10,  49 => 9,  30 => 2,  72 => 20,  67 => 24,  60 => 14,  55 => 12,  51 => 11,  46 => 11,  42 => 8,  39 => 6,  33 => 3,  31 => 4,  28 => 5,);
    }
}
