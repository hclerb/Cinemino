<?php

/* CineminotestBundle::layout.html.twig */
class __TwigTemplate_5b6a9066838cdcc8e2d9221621ee5c8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'info' => array($this, 'block_info'),
            'alert' => array($this, 'block_alert'),
            'titre' => array($this, 'block_titre'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        // line 3
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 8
    public function block_info($context, array $blocks = array())
    {
        // line 9
        echo " ";
        // line 11
        echo "
     <div class=\"span4\" style=\"margin-left:0px;\" >
      <div class=\"alert alert-success\">
        <strong>Success !</strong><br> 
        Vous vous êtes correctement loggé,<br> 
        bienvenue sur le panel admin Cinémino.<br>
      </div>
    </div>

    <div class=\"span4\">
      <div class=\"alert alert-info\">
        <strong>Utilisateur : </strong> ";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "user"), "username"), "html", null, true);
        echo " <br>
<strong>Dernière connexion : </strong> ";
        // line 23
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "user"), "lastlogin"), "d/m/Y"), "html", null, true);
        echo " <br>
<strong>Rôle(s) : </strong> ";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "user"), "roles"), 0, array(), "array"), "html", null, true);
        echo "
      </div>
    </div>


  <div class=\"row\">
    <div class=\"span12\">
        <div class=\"alert alert-block\">
          <h4 class=\"alert-heading\">Information</h4>
          <p>";
        // line 33
        $this->displayBlock('alert', $context, $blocks);
        // line 36
        echo "          </p>
        </div>
    </div>
  </div>
<div class=\"page-header\">
 <h3>";
        // line 41
        $this->displayBlock('titre', $context, $blocks);
        echo "</h3>
 </div>
 
 ";
        // line 46
        echo " ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "session"), "getFlashes", array(), "method"));
        foreach ($context['_seq'] as $context["key"] => $context["flash"]) {
            // line 47
            echo "  <div class=\"alert alert-";
            echo twig_escape_filter($this->env, $this->getContext($context, "key"), "html", null, true);
            echo "\">
   ";
            // line 48
            echo twig_escape_filter($this->env, $this->getContext($context, "flash"), "html", null, true);
            echo "
  </div>
 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['flash'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 51
        echo " ";
        // line 53
        echo " ";
        $this->displayBlock('content', $context, $blocks);
    }

    // line 33
    public function block_alert($context, array $blocks = array())
    {
        echo "  Vous pouvez dès à présent gérer vos séances, cinémas, évènements etc... selon vos droits d'accès.
              Vous pouvez voir les informations realtifs à vos droits sur la page d'accueil.<br>
              ";
    }

    // line 41
    public function block_titre($context, array $blocks = array())
    {
    }

    // line 53
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "CineminotestBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 53,  128 => 41,  120 => 33,  115 => 53,  113 => 51,  104 => 48,  99 => 47,  94 => 46,  88 => 41,  81 => 36,  67 => 24,  63 => 23,  59 => 22,  46 => 11,  44 => 9,  41 => 8,  35 => 3,  32 => 2,  117 => 29,  114 => 28,  107 => 30,  105 => 28,  101 => 26,  92 => 23,  87 => 22,  83 => 21,  79 => 33,  71 => 17,  65 => 14,  61 => 13,  56 => 12,  54 => 11,  50 => 9,  47 => 8,  40 => 6,  34 => 3,  31 => 2,);
    }
}
