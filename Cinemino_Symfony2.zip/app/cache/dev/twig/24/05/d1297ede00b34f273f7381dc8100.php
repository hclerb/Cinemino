<?php

/* TwigBundle:Exception:logs.html.twig */
class __TwigTemplate_2405d1297ede00b34f273f7381dc8100 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ol class=\"traces logs\">
    ";
        // line 2
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "logs"));
        foreach ($context['_seq'] as $context["_key"] => $context["log"]) {
            // line 3
            echo "        <li";
            if (($this->getAttribute($this->getContext($context, "log"), "priority") >= 400)) {
                echo " class=\"error\"";
            } elseif (($this->getAttribute($this->getContext($context, "log"), "priority") >= 300)) {
                echo " class=\"warning\"";
            }
            echo ">
            ";
            // line 4
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "log"), "priorityName"), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "log"), "message"), "html", null, true);
            echo "
        </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['log'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 7
        echo "</ol>
";
    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:logs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 20,  84 => 19,  74 => 16,  66 => 15,  57 => 14,  36 => 7,  25 => 4,  105 => 24,  98 => 22,  96 => 21,  93 => 20,  89 => 19,  83 => 18,  76 => 16,  68 => 12,  50 => 8,  27 => 4,  24 => 3,  225 => 96,  216 => 90,  212 => 88,  205 => 84,  201 => 83,  196 => 80,  194 => 79,  191 => 78,  189 => 77,  186 => 76,  180 => 72,  178 => 71,  172 => 67,  163 => 63,  159 => 61,  157 => 60,  154 => 59,  147 => 55,  143 => 54,  138 => 51,  136 => 50,  132 => 48,  130 => 47,  127 => 46,  121 => 45,  118 => 44,  114 => 43,  100 => 34,  95 => 31,  78 => 28,  71 => 26,  58 => 9,  34 => 11,  19 => 1,  26 => 3,  21 => 2,  43 => 7,  29 => 3,  198 => 80,  193 => 76,  187 => 5,  177 => 115,  173 => 114,  169 => 113,  126 => 76,  106 => 59,  102 => 58,  97 => 56,  82 => 44,  75 => 27,  48 => 19,  40 => 14,  22 => 2,  133 => 80,  128 => 77,  120 => 33,  115 => 53,  113 => 51,  104 => 36,  99 => 47,  94 => 39,  88 => 6,  81 => 40,  79 => 17,  63 => 24,  59 => 22,  44 => 10,  41 => 9,  35 => 4,  32 => 4,  54 => 11,  52 => 10,  49 => 9,  30 => 2,  72 => 14,  67 => 24,  60 => 23,  55 => 13,  51 => 12,  46 => 7,  42 => 8,  39 => 6,  33 => 5,  31 => 5,  28 => 5,);
    }
}
